# Kilas Bersih
Website resmi untuk usaha cuci sepatu dan tas.

## Fitur
- Booking via WhatsApp
- Testimoni pelanggan
- Galeri before-after
- Informasi layanan

## Cara Deploy
- Upload ke Netlify
- Atur publish directory: `.`